CREATE DATABASE shop;
CREATE TABLE IF NOT EXISTS shop.user (id integer,email varchar(70) ,first_name  varchar(40) , last_name  varchar(40) , pass varchar(500) );
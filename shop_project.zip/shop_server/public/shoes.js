
// exports.shoes = (req, res) => {
//     res.json({
//         "id": 1,
//         "category": "Jordan 1 high",
//         "sneakerName": "AIR JORDAN 1 HIGH ZOOM 'RACER BLUE",
//         "imageUrl": "https://cdn.flightclub.com/1500/TEMPLATE/164667/1.jpg",
//         "size": [
//             40,
//             41,
//             42,
//             43,
//             44,
//             45,
//             46,
//             47
//         ],
//         "price": 200
//     },
//         {
//             "id": 2,
//             "category": "Jordan 1 high",
//             "sneakerName": "WMNS AIR JORDAN 1 HIGH OG 'COURT PURPLE",
//             "imageUrl": "https://cdn.flightclub.com/1500/TEMPLATE/191046/1.jpg",
//             "size": [
//                 40,
//                 41,
//                 42,
//                 43,
//                 44,
//                 45,
//                 46,
//                 47
//             ],
//             "price": 160

//         }
//     )
// }


